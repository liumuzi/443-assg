#include "mysr.h"

void mysr_init_sender(struct mysr_sender* mysr_sender, char* ip, int port, int N, int timeout){

}

int mysr_send(struct mysr_sender* mysr_sender, unsigned char* buf, int len){
  return 0;
}

void mysr_close_sender(struct mysr_sender* mysr_sender){

}

void mysr_init_receiver(struct mysr_receiver* mysr_receiver, int port){

}

int mysr_recv(struct mysr_receiver* mysr_receiver, unsigned char* buf, int len){
  return 0;
}

void mysr_close_receiver(struct mysr_receiver* mysr_receiver) {

}
